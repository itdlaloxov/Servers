const PiranhaMessage = require('../Utils/PiranhaMessage')
const ByteStream = require("../Utils/ByteStream")
const database = require("../Laser.Server/db")
const LoginFailedMessage = require('../Laser.Logic/Account/LoginFailedMessage')
const config = require("../config.json")

const fs = require('fs');
class LogicSetPlayerNameColorCommand extends PiranhaMessage{
    constructor(bytes, session){
        super(bytes)
        this.session = session;
        this.commandID = 527
        this.version = 0
        this.stream = new ByteStream(bytes)

    }

    decode(self){
        for (let i of Array(10).keys()){this.stream.readVInt()}   
        this.session.Namecolor = this.stream.readVInt()
    }
    
    async process() {
        if(this.session.Namecolor >= 12){
            const vipData = await fs.readFile('./Utils/vips.json', 'utf8');
            const vipParsed = JSON.parse(vipData);
            const foundItem = vipParsed.find(item => item.id === this.session.lowID);
            if(foundItem){
                await database.replaceValue(this.session.lowID, 'Namecolor', this.session.Namecolor);
            }else{
                return new LoginFailedMessage(this.session, `У вас нету ${config.serverName} PREMIUM Купить через ТГ ${config.BotPREMIUM}`, 11).send();
            }
        }else{
			await database.replaceValue(this.session.lowID, 'Namecolor', this.session.Namecolor);
		}
    }
}

module.exports = LogicSetPlayerNameColorCommand