const PiranhaMessage = require('../Utils/PiranhaMessage')
const ByteStream = require("../Utils/ByteStream")
const database = require("../Laser.Server/db")

class LogicSetPlayerThumbnailCommand extends PiranhaMessage{
    constructor(bytes, session){
        super(bytes)
        this.session = session;
        this.commandID = 505
        this.version = 0
        this.stream = new ByteStream(bytes)
    }

    decode(self){
        for (let i of Array(10).keys()){this.stream.readVInt()}   
        this.Thumbnail = this.stream.readVInt()
    }

    async process(){
        this.session.Thumbnail = this.Thumbnail
        await database.replaceValue(this.session.lowID, 'Thumbnail', this.Thumbnail);
    }
}

module.exports = LogicSetPlayerThumbnailCommand