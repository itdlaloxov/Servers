const fs = require('fs')

class CommandManager {
  constructor () {
    this.commands = {}

    fs.readdir('./Laser.Commands', (err, files) => {
      if (err)console.log(err)
      files.forEach(e => {
        const Command = require(`../Laser.Commands/${e.replace('.js', '')}`)
        const commandClass = new Command()

        this.commands[commandClass.commandID] = Command
      })
    })
  }

  handle (id) {
    return this.commands[id]
  };

  getCommands () {
    return Object.keys(this.commands)
  }
}

module.exports = CommandManager