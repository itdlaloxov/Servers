class ClientInput {
  decode(stream, player, battle) {
    this.stream = stream;
    this.counter = this.stream.readVInt();
    this.id = this.stream.readVInt()
    if (this.counter !== 0){
      if (this.id === 2){
        player.destinationX = this.stream.readVInt();
        player.destinationY = this.stream.readVInt();
        let angleInRadians = Math.atan2(player.destinationY - player.y, player.destinationX - player.x);
        player.angle = (angleInRadians * 180 / Math.PI + 360) % 360;
      }
    }
  }
}

module.exports = ClientInput;