class Character {
    constructor(bitStream, player, isOwn) {
      this.bitStream = bitStream;
      this.player = player;
      this.isOwn = isOwn;
    }
  
    encode() {
      this.bitStream.writePositiveVInt(this.player.x, 4);
      this.bitStream.writePositiveVInt(this.player.y, 4);
      this.bitStream.writePositiveVInt(this.player.index + 16 * this.player.team, 3);
      this.bitStream.writePositiveVInt(0, 4);
      this.bitStream.writePositiveInt(10, 4);
  
      if (this.isOwn) {
        this.bitStream.writeBoolean(false); // isownobj
      } else {
        this.bitStream.writePositiveInt(this.player.angle, 9); // isownobj
        this.bitStream.writePositiveInt(this.player.angle, 9); // isownobj
      }
  
      this.bitStream.writePositiveIntMax7(0);// this.player.m_state
      this.bitStream.writeBoolean(false);
      this.bitStream.writeInt(63, 6);
      this.bitStream.writeBoolean(false);// дёргает и не rotate
      this.bitStream.writeBoolean(false);// Stun
      this.bitStream.writeBoolean(false);// unk
      this.bitStream.writeBoolean(true);// star power indicator
      this.bitStream.writePositiveVIntMax255OftenZero(0);
      this.bitStream.writePositiveVIntMax255OftenZero(0);
      this.bitStream.writeBoolean(false);
      this.bitStream.writeBoolean(false);
      this.bitStream.writePositiveInt(0, 2);
      this.bitStream.writePositiveInt(this.player.Hitpoints, 13); // hp
      this.bitStream.writePositiveInt(this.player.maxHitpoints, 13); // max hp
      this.bitStream.writePositiveVIntMax255OftenZero(this.player.itemCount);
      this.bitStream.writePositiveVIntMax255OftenZero(0);
      this.bitStream.writeBoolean(false); // big brawler
      this.bitStream.writeBoolean(false); // this.player.IsChargeActive
      this.bitStream.writeBoolean(false); // this.player.Shield // Immunity 
      this.bitStream.writeBoolean(false);
      this.bitStream.writeBoolean(false);
      this.bitStream.writeBoolean(false); // this.player.ultiactive press ulti
      this.bitStream.writeBoolean(false); // is own
      if (this.isOwn) this.bitStream.WritePositiveIntMax15(0); // is own
      // if (this.player.IsChargeActive)
      // {
      //   this.bitStream.writePositiveInt(0, 10);
      //   this.bitStream.WritePositiveIntMax15(0);
      // }
      this.bitStream.writePositiveInt(0, 2);
      this.bitStream.writeBoolean(false);
      this.bitStream.writePositiveInt(0, 9);
  
      if (this.isOwn) this.bitStream.writeBoolean(false); // is own
  
      this.bitStream.writePositiveInt(0, 5);//this.player.damageIndicator.length
    //   for (const data of this.player.damageIndicator) {
    //     this.bitStream.writeInt(data.damage, 15);
    //   }
      this.bitStream.writePositiveVIntMax255OftenZero(0);//this.player.IsChargeActive === true ? 1 : 0
      this.bitStream.writeBoolean(false);
      this.bitStream.writePositiveVIntMax255OftenZero(0);
      this.bitStream.writePositiveInt(3000, 12);
      this.bitStream.writePositiveVIntMax255OftenZero(0);
      this.bitStream.writeBoolean(false);
      this.bitStream.writePositiveVIntMax255OftenZero(0);
    }
  }
  
  module.exports = Character;
  