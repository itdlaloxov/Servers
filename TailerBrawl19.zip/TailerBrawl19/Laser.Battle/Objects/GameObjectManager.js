const Character = require('./Character');


class LogicGameObjectManagerServer {
  constructor(bitStream, battle, player) {
    this.bitStream = bitStream;
    this.player = player;
    this.battle = battle;
    this.playerLeft = 0;
  }

  encode() {
    const { bitStream, battle, player } = this;
    const playerLowID = player.lowID;
    const GameObjects = battle.GameObjects;
    bitStream.writePositiveInt(1000000 + playerLowID, 21);
    bitStream.writePositiveVInt(0, 4);
    bitStream.writeBoolean(false);
    bitStream.writeInt(-1, 4);

    bitStream.writeBoolean(true);
    bitStream.writeBoolean(true);
    bitStream.writeBoolean(true);
    bitStream.writeBoolean(false);

    bitStream.WritePositiveIntMax31(0);
    bitStream.WritePositiveIntMax31(0);
    bitStream.WritePositiveIntMax31(0);
    bitStream.WritePositiveIntMax31(0);

    bitStream.writeBoolean(false);

    for (let i = 0; i < 6; i++) {
      bitStream.writeBoolean(false);
      bitStream.writeBoolean(false);
      if (i === 0) {
        bitStream.writePositiveInt(0, 12);
        bitStream.writeBoolean(false);
      }
    }

    for (let i = 0; i < 6; i++) {
      bitStream.writeBoolean(true);
      bitStream.writePositiveVIntMax255(0);//гемы
      bitStream.writeBoolean(false)
    }
    bitStream.writePositiveInt(0, 7);
    // GameObjects.forEach(i => {
    //   bitStream.writePositiveInt(i.ClassId, 5);
    //   bitStream.writePositiveInt(i.InstanceId, 7);
    // });

    // GameObjects.forEach(i => {
    //   bitStream.writePositiveInt(i.lowID, 14);
    // });

    // GameObjects.forEach(data => {
    //     if (data.Type === "brawler") {
    //         new Character(bitStream, data, data.lowID === playerLowID).encode();
    //     }
    // });
  }
}

module.exports = LogicGameObjectManagerServer;