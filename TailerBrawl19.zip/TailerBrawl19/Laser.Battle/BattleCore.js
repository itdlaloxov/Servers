const UDPConnectionInfo = require('../Laser.Logic/Battle/UDPConnectionInfo');
const VisionUpdateMessage = require('../Laser.Logic/Battle/VisionUpdateMessage');
const StartLoadingMessage = require('../Laser.Logic/Battle/StartLoadingMessage');

class BattleCore {
  constructor(battle) {
    this.battle = battle
    this.playerLeft = 0;
  }

  run() {
    this.battle.started = true
    this.startBattle();
  }

  startBattle() {
    this.battle.players.forEach(e => {
      e.battleTick = 0;
      e.x = 3250
      e.y = 9500
      e.counter = 0
      e.destinationX = 3250
      e.destinationY = 9500
      this.battle.GameObjects.push(e)
    });

    this.battle.players.forEach(e => {
      new StartLoadingMessage(e.session, e, this.battle).send(e.lowID);
      new UDPConnectionInfo(e.session, e, this.battle).send(e.lowID);
    });

    const battleInterval = setInterval(() => {
      if (!this.battle.started) {
        clearInterval(battleInterval);
      }
      this.battle.Tick += 1;
      this.process();
    }, 50);
  }

  process() {
    this.battle.players.forEach(e => {
      new VisionUpdateMessage(e.session, this.battle, e).send(e.lowID);
    });
  }
}

module.exports = BattleCore;

