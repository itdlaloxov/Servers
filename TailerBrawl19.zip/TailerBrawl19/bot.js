const { Telegraf, Markup } = require('telegraf');
const LocalSession = require('telegraf-session-local');
const processHashtag = require('./lowID');
const database = require("./Laser.Server/db");
const tgacc = require('./Laser.Server/tgacc.json');
const fs = require('fs').promises;
const vips = require('./Laser.Server/vips.json');

// Replace 'YOUR_TELEGRAM_BOT_TOKEN' with your bot token
const token = '';
const bot = new Telegraf(token);

const Shop = require("./Utils/Shop");
const Gameroom = require('./Laser.Server/Gameroom');
const gameroomInstance = new Gameroom();

const config = require('./config.json');


const session = new LocalSession({
  database: 'sessions.json',
  storage: LocalSession.storageFileAsync,
  format: {
    serialize: (obj) => JSON.stringify(obj, null, 2),
    deserialize: (str) => JSON.parse(str),
  },
});

bot.use(session.middleware());

// Handler for /start command
bot.command('start', async (ctx) => {
  try {
    ctx.session.keyboard = [
      [{ text: '👥Поддержка' }]
    ]

    const fined = tgacc.find(plr => plr.id === ctx.message.from.id);
    if (!fined){
      ctx.session.keyboard.push([{ text: '🔮Привязать аккаунт' }])
    }else ctx.session.keyboard.push([{ text: '💎Мой аккаунт' }]);

    const sentMessage = await ctx.replyWithHTML(
      `<b>Привет!\nВыберите действие:</b>`,
      {
        reply_markup: {
          keyboard: ctx.session.keyboard,
          resize_keyboard: true,
          one_time_keyboard: true
        }
      }
    );
    ctx.session.message_id = sentMessage.message_id;
    ctx.session.TGID = sentMessage.chat.id;

    ctx.session.started = true;

  } catch (error) {
    console.log(error);
  }
});

bot.on('text', async (ctx) => {
  const messageText = ctx.message.text;
  const userId = ctx.message.from.id;
  if (ctx.session.started) {
    try {

      switch (true) {
        case (messageText.startsWith('👥Поддержка')): {
          await ctx.replyWithHTML(`<b>Задать любой вопрос касаемо игры пишите - @sb0manager</b>`,
            {
              reply_markup: {
                keyboard: ctx.session.keyboard,
                resize_keyboard: true,
                one_time_keyboard: true
              }
            }
          );
          break;
        }
        case (messageText.startsWith('💎Мой аккаунт')): {
          const account = await database.getAccount(ctx.session.plrID);
          await ctx.reply(`Привет ${account.Name}!\nТрофеев: ${Math.floor(account.Trophies)}\nДля захода на аккаунт, вы должны создать новый аккунт.\nПосле написать /join #ТЕГ_НОВОГО_АККАУНТА`);
          break;
        }
        case (messageText.startsWith('/join')): {
          const commandParams = ctx.message.text.split(' ');
          if(commandParams[1] === undefined) return await ctx.reply(`Нужно написать /join ТЕГ_НОВОГО_АККАУНТА`);
          
          const tag = commandParams[1];
          const regex = /[OoОо]/;
        
          if (regex.test(tag)) return await ctx.reply(`Тег содержит букву "O"!\nЗамени на цифру 0`);
          
          const playerId = processHashtag(tag);
          if (playerId === 0) return await ctx.reply(`Вы неправильно указали тег!`);
          
          if (playerId === ctx.session.plrID) return await ctx.reply(`Для захода на аккаунт, вы должны создать новый аккунт.\nПосле написать /join #ТЕГ_НОВОГО_АККАУНТА`);
          
          const fined = tgacc.find(plr => plr.id === ctx.message.from.id);

          if (fined === undefined) return await ctx.reply(`Вы не владелец аккаунта!`);

          const newacc = await database.getAccount(playerId);
          const oldacc = await database.getAccount(ctx.session.plrID);

          if(newacc.token === null) return await ctx.reply(`Произошла ошибка создайте новый аккаунт еще раз!`);
          await database.replaceValue(oldacc.lowID, 'token', newacc.token);
          await database.replaceValue(newacc.lowID, 'token', "");

          await ctx.reply(`Аккаунт был восстановлен!\nПерезайдите в игру.`);
          break;
        }
        case (messageText.startsWith('🔮Привязать аккаунт')): {
          await ctx.replyWithHTML(`<b>Для привязки аккаунта\nНапишите /link #ВАШ_АЙДИ</b>`,
            {
              reply_markup: {
                keyboard: ctx.session.keyboard,
                resize_keyboard: true,
                one_time_keyboard: true
              }
            }
          );
          break;
        }
        case (messageText.startsWith('/link')): {
          const commandParams = messageText.split(' ');
        
          if (commandParams.length < 2) return await ctx.reply(`Вы не указали тег!`);
          
          const tag = commandParams[1];
          const regex = /[OoОо]/;
        
          if (regex.test(tag)) return await ctx.reply(`Тег содержит букву "O"!\nЗамени на цифру 0`);
          
          const playerId = processHashtag(tag);
          if (playerId === 0) return await ctx.reply(`Вы неправильно указали тег!`);
          ctx.session.plrID = playerId;
          if (tgacc.find(acc => acc.lowID == playerId)) return await ctx.reply(`Данный аккаунт уже привязан!`)
          const account = await database.getAccount(playerId)

          account.Notification = account.Notification.filter(notification => !notification.text.startsWith('Вы начали привязку аккаунта.'));

          const newCode = Math.floor(Math.random() * 9999) + 1000;
          account.Notification.push({
              ID: 81,
              index: parseInt(account.Notification.length+1),
              type: 0,
              date: new Date(),
              text: `Вы начали привязку аккаунта.\nВАШ КОД: ${newCode}`
          });
          
          await database.replaceValue(playerId, 'Notification', account.Notification);
          ctx.session.code = newCode;

          ctx.reply(`Привет ${account.Name}!\nКод авторизации пришел на ваш аккаунт.\nЗайди в игру и запомните код и отправьте:\n/code ВАШ КОД`)
          break;
        }
        case (messageText.startsWith('/code')): {
          const commandParams = messageText.split(' ');
        
          if (commandParams.length < 2) return await ctx.reply(`Вы не указали код!`);
          
          const code = commandParams[1];
          if (parseInt(code) === ctx.session.code){
              ctx.session.code = null
              const account = await database.getAccount(ctx.session.plrID);
              account.Notification = account.Notification.filter(notification => !notification.text.startsWith('Вы начали привязку аккаунта.'));
              account.Notification = account.Notification.filter(notification => !notification.text.startsWith('Ваш аккаунт привязан к TailerID'));
              account.Notification.push({
                ID: 94,
                index: parseInt(account.Notification.length+1),
                reward: 59,
                type: 29,
                date: new Date(),
                claim: false,
                text: `Ваш аккаунт привязан к TailerID`
              });
              await database.replaceValue(ctx.session.plrID, 'Notification', account.Notification);
              tgacc.push({id: userId,lowID: ctx.session.plrID})
              fs.writeFile('./Laser.Server/tgacc.json', JSON.stringify(tgacc, null, 2), (err) => {if (err) {console.error('Ошибка сохранения файла с конфигурацией:', err)}});
              ctx.session.keyboard = [
                [{ text: '👥Поддержка' }],
                [{ text: '💎Мой аккаунт' }]
              ];
              await ctx.replyWithHTML(
                  '<b>Аккаунт успешно привязан!\nВыберите действие:</b>',
                  {
                    reply_markup: {
                      keyboard: ctx.session.keyboard,
                      resize_keyboard: true,
                      one_time_keyboard: true
                    }
                  }
                );
              break;
          }else{
              ctx.session.code = 0 
              ctx.session.plrID = 0
              await ctx.reply(`Вы неправильно ввели код!\nПопробуйте пройти привязку сново.`);
              break;
          }
        }

        case (messageText.startsWith('/getID')): {
          const info = messageText.split(' ');
          await ctx.reply(`Успешно! ${parseInt(processHashtag(info[1]))}`);
          break;
        }
        case (messageText.startsWith('/reward')): {
          if (!config.admins.includes(parseInt(userId))) return await ctx.reply('Нет прав! ' + userId);
        
          const commandParams = messageText.split(' ');
          if (commandParams.length !== 3)  return await ctx.reply('Недостаточно параметров.');
        
          const hashtag = commandParams[1];
          const value = commandParams[2];

          const returnedID = processHashtag(hashtag);
          if (returnedID === 0) return await ctx.reply('Букву О на цифру 0 да.');
        
          const account = await database.getAccount(parseInt(returnedID));
          if (account === null) return await ctx.reply('Аккаунт не найден!');
          
          account.Notification.push({
            ID: 89,
            index: account.Notification.length*2,
            reward: value,
            type: 0,
            date: new Date(),
            claim: false,
            text: ``
          })
          
          await database.replaceValue(parseInt(returnedID), 'Notification', account.Notification);

          await ctx.reply('Успешно!');
          break;
        }
        case (messageText.startsWith('/ResetAllShop')): {
          if(!config.admins.includes(parseInt(userId))){
            await ctx.reply('Нет прав!' + userId);
            break
          }
          await database.resetShop();
          await ctx.reply(`Успешно!`);
        }
        case (messageText.startsWith('/addAllShop')): {
          if(!config.admins.includes(parseInt(userId))){
            await ctx.reply('Нет прав!' + userId);
            break
          }
          const commandParams = messageText.split(' ');
          const offerData = commandParams.slice(1).join(' ');
          await new Shop().giftAllPlayer(JSON.parse(offerData));
          await ctx.reply('Успешно!');
          break;
        }
        case (messageText.startsWith('/giveoffers')): {
          const commandParams = messageText.split(' ');

          if (commandParams.length < 3) return await ctx.reply('Комманда не найдена.')

          const hashtag = commandParams[1];
          const offerData = commandParams.slice(2).join(' ');

          const account = await database.getAccount(parseInt(processHashtag(hashtag)));

          if (!account) return await ctx.reply('Игрок не найден.')

          const OffersParsed = JSON.parse(offerData)
          const EndDate = new Date()
          EndDate.setDate(EndDate.getDate() + 1);
          EndDate.setHours(9, 0, 0, 0);
  
          OffersParsed.EndDate = EndDate;
          OffersParsed.claim = false;

          account.Shop.push(OffersParsed);

          await database.replaceValue(account.lowID, 'Shop', account.Shop);

          await ctx.reply('Новая акция успешно добавлена для игрока.');
          break;
      }
      case (messageText.startsWith('/delshop')): {
        if(!config.admins.includes(parseInt(userId))){
          await ctx.reply('Нет прав!' + userId);
          break
        }
        const commandParams = messageText.split(' ');

        if (commandParams.length < 2) {
          await ctx.reply('Недостаточно параметров.');
        }
        const playerId = processHashtag(commandParams[1]);

        await database.replaceValue(parseInt(playerId), 'Shop', []);

        await ctx.reply('Акции удалены!');
        break;
      }
      case (messageText.startsWith('/replace')): {
        if (!config.admins.includes(parseInt(userId))) {
          await ctx.reply('Нет прав!' + userId);
          break;
        }
      
        const commandParams = messageText.split(' ');
        if (commandParams.length !== 4) {
          await ctx.reply('Неверный формат команды');
          break;
        }
      
        const hashtag = commandParams[1];
        const resourceType = commandParams[2];
        const value = commandParams[3];

        const returnedID = processHashtag(hashtag);
        if (returnedID === 0) {
          return await ctx.reply('Букву О на цифру 0 да.');
        }
      
        const account = await database.getAccount(parseInt(returnedID));
      
        const Resources = {
          Gems: 'Gems',
          Box: 'Box',
          Gold: 'Gold',
          BigBox: 'BigBox',
          Starpoints: 'Starpoints',
          Tickets: 'Tickets',
          TokensDoubler: 'TokensDoubler'
          };
      
        if (resourceType === 'Name') {
          await database.replaceValue(account.lowID, resourceType, value);
        } else if (resourceType === 'Skins') {
          if (value === '[]') {
            await database.replaceValue(account.lowID, resourceType, []);
          } else {
            account.Skins.push(parseInt(value));
            await database.replaceValue(account.lowID, resourceType, account.Skins);
          }
        } else if (Resources.hasOwnProperty(resourceType)) {
          account.Resources[resourceType] += parseInt(value);
          await database.replaceValue(account.lowID, 'Resources', account.Resources);
        } else {
          await ctx.reply('Неверный тип ресурса');
          break;
        }
      
        await ctx.reply('Успешно!');
        break;
      }
      case (messageText.startsWith('/vipADD')): {
        if(!config.admins.includes(parseInt(userId))){
          await ctx.reply('Нет прав!' + userId);
          break
        }
        const commandParams = ctx.message.text.split(' ');
          
        const playerId = processHashtag(commandParams[1]);
        const account = await database.getAccount(parseInt(playerId))
        if(account){
          account.Resources.Gems += 170;
          await database.replaceValue(parseInt(playerId), 'Resources', account.Resources)
          const newVip = { id: parseInt(playerId), gived: false };
          vips.push(newVip);
          fs.writeFile('./Laser.Server/vips.json', JSON.stringify(vips, null, 2), (err) => {
            if (err) {
              console.error('Ошибка сохранения файла с конфигурацией:', err);
            }
          });
        } else return await ctx.reply(`Аккаунт не найден!`);
        await ctx.reply(`Выдали. ${playerId}`);
        break;
        }
      case (messageText.startsWith('/ban')): {
        if(!config.admins.includes(parseInt(userId))){
          await ctx.reply('Нет прав!' + userId);
          break
        }
        const commandParams = ctx.message.text.split(' ');
          
        const playerId = processHashtag(commandParams[1]);
        if (playerId === 0) return await ctx.reply('Букву О на цифру 0 да.')

          await database.replaceValue(playerId, 'Brawlers', [])
          await database.replaceValue(playerId, 'Trophies', 0)
          await database.replaceValue(playerId, 'Name', "Забанен")

          await ctx.reply(`Забанен`);
          break;
        }
      case (messageText.startsWith('/clubban')): {
        if(!config.admins.includes(parseInt(userId))){
          await ctx.reply('Нет прав!' + userId);
          break
        }
        const commandParams = ctx.message.text.split(' ');
          
        const clubID = processHashtag(commandParams[1]);
        if (clubID === 0) return await ctx.reply('Букву О на цифру 0 да.')
          const c = {
              'Name': commandParams[2],
          };
          await database.clubUpdate(clubID, c);

          await ctx.reply(`Забанен`);
          break;
      }


      case (messageText.startsWith('/Statistics')): {
        if (!config.admins.includes(parseInt(userId))) {
          await ctx.reply('Нет прав!' + userId);
          break;
        }
        const rooms = gameroomInstance.getRooms();
        const currentDate = new Date();
        const StatisticsCollected = `${currentDate.getDate()}.${currentDate.getMonth() + 1}.${currentDate.getFullYear()} ${currentDate.getHours()}:${currentDate.getMinutes() < 10 ? '0' + currentDate.getMinutes() : currentDate.getMinutes()}`;
        const ServerStarted = `${global.ServerStarted.getDate()}.${global.ServerStarted.getMonth() + 1}.${global.ServerStarted.getFullYear()} ${global.ServerStarted.getHours()}:${global.ServerStarted.getMinutes() < 10 ? '0' + global.ServerStarted.getMinutes() : global.ServerStarted.getMinutes()}`;
        const rd = await database.getCounts();
        const data = {
          "Сервер был запущен": ServerStarted,
          "Количество игроков": global.online,
          "Игроков в день": rd.infodau,
          "Создано Команд": rooms.length,
          "Всего аккаунтов": rd.accountCount,
          "Всего Клубов": rd.clubCount,
          "Статистика Собрана": StatisticsCollected
        };
        let reply = "";
        for (const key in data) {
            reply += `"${key}": ${data[key]}\n`;
        }
        await ctx.reply(reply);
        break;
      }

      default: {
        await ctx.reply(`Комманда не найдена.\nНапишите /start`);
        break;
      }
    }
    } catch (error) {
      console.log(error);
    }
  } else {
    // If /start was not issued, proceed as usual
    await ctx.reply(`Пожалуйста, введите команду /start для начала.`);
  }
});

bot.catch((err, ctx) => {
  if (err.code === 403 && err.description.includes('blocked by the user')) {
      return;
  }
  console.error('Произошла ошибка:', err);
});


module.exports = bot;