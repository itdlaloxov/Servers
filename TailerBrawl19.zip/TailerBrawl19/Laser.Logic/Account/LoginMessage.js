const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
//Servers Packet
const LoginFailedMessage = require("./LoginFailedMessage")
const LoginOKMessage = require("./LoginOKMessage")
const OwnHomeDataMessage = require("../Home/OwnHomeDataMessage")
//database Calling
const database = require("../../Laser.Server/db")
const crypto = require('crypto');
const config = require("../../config.json")
const Shop = require("../../Utils/Shop")

const MyAllianceMessage = require('../Alliance/MyAllianceMessage')
const AllianceStreamEntryMessage = require('../Alliance/AllianceStreamEntryMessage')

class LoginMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.id = 10101
    this.version = 0
    this.stream = new ByteStream(bytes);
  }

  async decode () {
    this.stream.readInt()
    this.session.lowID = this.stream.readInt()
    this.session.token = this.stream.readString()

    this.major = this.stream.readInt()
    this.minor = this.stream.readInt()
    this.build = this.stream.readInt()
    this.fingerprint_sha = this.stream.readString() 
    this.DeviceModel = this.stream.readString()
    this.isAndroid = this.stream.readVInt()
  }

  async process () {

    if (this.isAndroid !== 0 & this.fingerprint_sha !== config.cryptoKey || this.major !== config.major) {
      return await new LoginFailedMessage(this.session, `Отличные новости! Доступна новая версия ${config.serverName}Brawl\nGreat news! New version available ${config.serverName}Brawl`, 8).send();
    }

    if (!this.session.token) {
      this.session.token = crypto.randomBytes(Math.ceil(36/2)).toString('hex').slice(0, 36);
      await database.createAccount(this.session.token);
    }

    const account = await database.getAccountToken(this.session.token);
    if(account == null) return await new LoginFailedMessage(this.session, `Ваш аккаунт не найден, нужно удалить данные об игре!`, 18).send();

    if (account.Shop.length === 0 || account.Shop[0].EndDate === undefined || Math.floor((new Date(account.Shop[0].EndDate) - new Date()) / 1000) <= 0) {
      account.Shop = new Shop().generateShop(account);
      await database.replaceValue(account.lowID, 'Shop', account.Shop);
    }

    this.session.lowID = account.lowID;
    this.session.Resources = account.Resources;
    await new LoginOKMessage(this.session).send();
    await new OwnHomeDataMessage(this.session, account).send();

    if (account.ClubID !== 0) {
      let gettingClub = await database.getClub(account.ClubID);
      if (gettingClub !== null) {
        if (!gettingClub.members.includes(this.session.lowID)) {
          await database.replaceValue(this.session.lowID, 'ClubID', 0);
        } else {
          this.session.ClubRole = account.ClubRole;
          this.session.ClubID = account.ClubID;
          await new MyAllianceMessage(this.session, gettingClub, false).send();
          gettingClub.msg.forEach(async e =>  {
           await new AllianceStreamEntryMessage(this.session, e).send()
          });
        }
      } else {
        await database.replaceValue(this.session.lowID, 'ClubID', 0);
      }
    }

  }
}

module.exports = LoginMessage