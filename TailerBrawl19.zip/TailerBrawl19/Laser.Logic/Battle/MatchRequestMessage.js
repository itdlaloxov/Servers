const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const MatchMakingStatusMessage = require("./MatchMakingStatusMessage")
const UDPConnectionInfo = require("./UDPConnectionInfo")

//database Calling
const database = require("../../Laser.Server/db")
const Events = require('../../Utils/Events');
const Battles = require('../../Laser.Server/Battles');
const BattleCore = require('../../Laser.Battle/BattleCore')
const CallingBattles = new Battles()

class MatchRequestMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 14103
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.brawlerID = this.stream.readVInt()
    this.stream.readVInt()
    this.EventSlot = this.stream.readVInt()
    // ***
    // EventSlot
    // 1 - GemGrab
    // 2 - Showndoun
    // 5 - DuoShowndoun
  }

  async process () {
    const EventID = new Events().getIdBySlotID(this.EventSlot);

    const player = {
      session: this.session,
      lowID: this.session.lowID,
      Name: this.session.Name,
      Namecolor: this.session.Namecolor,
      brawlerID: this.brawlerID,
    }
    const battle = CallingBattles.search(this.EventSlot, EventID, player);
    
    this.session.battleID = battle.id;

    for (const i of battle.players) {
        new MatchMakingStatusMessage(i.session, battle).sendLowID(i.lowID);
    }

    // if(battle.players.length === battle.maxPlayers){
    //   for (const i of battle.players) {
    //       new UDPConnectionInfo(i.session).sendLowID(i.lowID);
    //   }
    //   const BattleC = new BattleCore(battle);
    //   BattleC.run();
    // }
  }
}

module.exports = MatchRequestMessage
