const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class UDPConnectionInfo extends PiranhaMessage {
  constructor (session) {
    super(session)
    this.id = 24112
    this.session = session
    this.version = 0
    this.stream = new ByteStream()
  }

  async encode () {
    this.stream.writeVInt(1111);
    this.stream.writeString();
    this.stream.writeInt(0);
    this.stream.writeByte(0);
    this.stream.writeInt(1);
    this.stream.writeByte(0);
  }
}

module.exports = UDPConnectionInfo
