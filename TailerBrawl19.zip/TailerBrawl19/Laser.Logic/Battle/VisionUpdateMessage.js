const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

const BitStream = require('../../Laser.Battle/BitStream')
const GameObjectManager = require('../../Laser.Battle/Objects/GameObjectManager')

class VisionUpdateMessage extends PiranhaMessage {
  constructor(session, battle, player) {
    super(session);
    this.id = 24109;
    this.session = session;
    this.player = player;
    this.battle = battle;
    this.version = 1;
    this.playerLeft = 0;
    this.stream = new ByteStream();

  }

  encode() {
    this.stream.writeVInt(this.battle.Tick);//battleTick
    this.stream.writeVInt(this.player.counter);//dudu
    this.stream.writeVInt(0);//command count
    this.stream.writeVInt(this.battle.Tick); //views?*?
    this.stream.writeBoolean(false);//in live
    const bitStream = new BitStream();
    new GameObjectManager(bitStream, this.battle, this.player).encode();
    bitStream.writePositiveInt(0,8)
    this.stream.writeBytes(bitStream.getBuff());

  }
}

module.exports = VisionUpdateMessage;
