
const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const UDPConnectionInfo = require("./UDPConnectionInfo")
const StartLoadingMessage = require("./StartLoadingMessage")

//database Calling
const database = require("../../Laser.Server/db")
const Events = require('../../Utils/Events');
const Battles = require('../../Laser.Server/Battles');
const CallingBattles = new Battles()

class MatchRequestMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 14103
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.brawlerID = this.stream.readVInt()
    this.stream.readVInt()
    this.EventSlot = this.stream.readVInt()
    // ***
    // EventSlot
    // 1 - GemGrab
    // 2 - Showndoun
    // 5 - DuoShowndoun
  }

  async process () {
    new StartLoadingMessage(this.session).send();
    new UDPConnectionInfo(this.session).send();
  }
}

module.exports = MatchRequestMessage
