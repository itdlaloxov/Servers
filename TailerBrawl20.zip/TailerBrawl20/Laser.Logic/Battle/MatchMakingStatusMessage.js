
const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class MatchMakingStatusMessage extends PiranhaMessage {
  constructor (session,MatchMaking) {
    super(session)
    this.id = 20405
    this.session = session
    this.MatchMaking = MatchMaking
    this.version = 0
    this.stream = new ByteStream()
  }

  async encode () {
    this.stream.writeInt(0);
    this.stream.writeInt(this.MatchMaking.players.length);//founded
    this.stream.writeInt(this.MatchMaking.players.length);//max player
    this.stream.writeInt(0);
    this.stream.writeInt(0);
    this.stream.writeBoolean(false);
  }
}

module.exports = MatchMakingStatusMessage
