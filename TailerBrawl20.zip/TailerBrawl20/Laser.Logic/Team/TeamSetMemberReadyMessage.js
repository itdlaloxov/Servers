const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

const database = require("../../Laser.Server/db")

const TeamMessage = require('./TeamMessage');
const Gameroom = require('../../Laser.Server/Gameroom');

class TeamSetMemberReadyMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session);
    this.session = session;
    this.id = 14355;
    this.version = 0;
    this.stream = new ByteStream(bytes);
  }

  async decode () {
    this.bool = this.stream.readBoolean();
  }

  async process () {
    const Instance = new Gameroom()
    const roomInfo = Instance.setPlayerReady(this.session.roomID, this.session.lowID, this.bool);
    if (roomInfo !== null){
      for (const ids of roomInfo.players) {
        new TeamMessage(this.session, roomInfo).sendLowID(ids.lowID)
      }
    }
  }
}
module.exports = TeamSetMemberReadyMessage;
