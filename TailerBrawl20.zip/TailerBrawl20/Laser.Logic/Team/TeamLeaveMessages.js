const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class TeamLeaveMessages extends PiranhaMessage {
  constructor(session) {
    super(session);
    this.id = 24125;
    this.session = session;
    this.version = 1;
    this.stream = new ByteStream();
  }

  async encode() {
    this.session.roomID = 0
    this.stream.writeInt(0);
  }
}

module.exports = TeamLeaveMessages;
