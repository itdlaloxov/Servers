const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class TeamChatMessages extends PiranhaMessage {
  constructor(session, roomInfo) {
    super(session);
    this.id = 24131;
    this.session = session;
    this.version = 1;
    this.roomInfo = roomInfo;
    this.stream = new ByteStream();
  }

  async encode() {

    const lastPremadeEntry = this.roomInfo.msg[this.roomInfo.msg.length - 1];
    const fm =[]
    if (lastPremadeEntry){
      this.stream.writeVInt(0);
      this.stream.writeVInt(this.roomInfo.id);
      this.stream.writeVInt(1);
        this.stream.writeVInt(lastPremadeEntry.event);
        this.stream.writeVInt(0);
        this.stream.writeVInt(this.roomInfo.Tick);//Tick?
        this.stream.writeVInt(0);
        this.stream.writeVInt(lastPremadeEntry.id);//id
        this.stream.writeString(lastPremadeEntry.senderName);
        this.stream.writeVInt(0);
        this.stream.writeVInt(0);
        this.stream.writeVInt(0);
        if (lastPremadeEntry.event === 4){
          this.stream.writeVInt(lastPremadeEntry.msg);
          this.stream.writeVInt(1);
          this.stream.writeVInt(0);
          this.stream.writeVInt(lastPremadeEntry.senderID);
          this.stream.writeString(lastPremadeEntry.senderName);

        }else{
          this.stream.writeString(lastPremadeEntry.msg);
      }
    }
  }
}

module.exports = TeamChatMessages;
