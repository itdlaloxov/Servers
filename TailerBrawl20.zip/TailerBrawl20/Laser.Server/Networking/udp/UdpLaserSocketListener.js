const dgram = require('dgram');
const { ByteStream } = require('../../../Utils/ByteStream'); // Предполагается, что у вас есть модуль для работы с байтовыми потоками
const UdpLaserSocket = require('./UdpLaserSocket'); // Adjust the path based on your file structure
const BattleMode = require('../../../Laser.Battle/BattleMode');
const LogicPlayer = require('../../../Laser.Battle/LogicPlayer');

const Port = 1337;
let SessionSeed = 1;
const Sessions = new Map();
const BattleModes = [];

const socket = dgram.createSocket('udp4');

socket.bind(Port, () => {
    console.log(`Battle server listening on port ${Port}`);
});

socket.on('message', (msg, remote) => {
    const sessionId = new ByteStream(msg).readLong();
    new ByteStream(msg).readShort();

    const messageType = new ByteStream(msg).readVInt();
    const messageEncodingLength = new ByteStream(msg).readVInt();
    const messageBytes = new ByteStream(msg).readBytes(messageEncodingLength);
    const messageStream = new ByteStream(messageBytes);

    if (Sessions.has(sessionId)) {
        if (messageType === 10555) {
            if (!Sessions.get(sessionId).EndPoint) Sessions.get(sessionId).EndPoint = remote;
            const message = new ClientInputMessage(messageStream);
            message.stream = messageStream;
            message.decode();

            message.inputs.forEach(input => {
                input.sessionId = sessionId;
                Sessions.get(sessionId).battleMode.addInput(input);
            });
        } else {
            console.log(`UdpLaserSocketListener.OnReceive - non-udp message in UDP packet! Type: ${messageType}`);
        }
    } else {
        console.log('UdpLaserSocketListener.OnReceive - unknown session!');
    }
});

function createBattleSession(connection) {
    connection.udpSessionId = SessionSeed;
    SessionSeed++;
    const socket = new UdpLaserSocket(connection.udpSessionId, connection);
    Sessions.set(connection.udpSessionId, socket);

    const battleMode = new BattleMode();
    battleMode.sockets.push(socket);
    battleMode.players.set(connection.udpSessionId, new LogicPlayer(connection.udpSessionId, {
        Avatar: 1,
        SelectedCharacter: 0
    }));
    BattleModes.push(battleMode);

    socket.battleMode = battleMode;

    battleMode.initSinglePlayer();

    const message = new StartLoadingMessage(connection);
    message.location = Events.activeEvents[0].location;
    message.players = [...battleMode.players.values()];
    message.send();
}


module.exports = {
    createBattleSession
};
