class Alliance {
  constructor() {}
  ["encode"](c, d) {
    c.writeInt(0x0);
    c.writeInt(d.clubID);
    c.writeString(d.Name);
    c.writeDataReference(0x8, d.BadgeID);
    c.writeVInt(d.data.Type);
    c.writeVInt(d.members.length || 0x0);
    c.writeVInt(d.Trophies);
    c.writeVInt(d.data.Trophiesneeded);
    c.writeVInt(0x0);
    c.writeString('BY');
    c.writeVInt(0x0);
    //c.writeVInt(d.data.FriendlyFamily);
  }
}
module.exports = Alliance;