const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class TeamGameStartingMessage extends PiranhaMessage {
  constructor(session, mapID) {
    super(session);
    this.id = 24130;
    this.session = session;
    this.mapID = mapID;
    this.version = 1;
    this.stream = new ByteStream();
  }

  async encode() {
    this.stream.writeVInt(0);
    this.stream.writeVInt(0);
    this.stream.writeDataReference(15, this.mapID);
    
  }
}

module.exports = TeamGameStartingMessage;
