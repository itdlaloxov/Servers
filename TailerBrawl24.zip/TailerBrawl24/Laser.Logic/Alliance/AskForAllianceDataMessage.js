const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const database = require("../../Laser.Server/db")
const AllianceDataMessage = require("./AllianceDataMessage");
class AskForAllianceDataMessage extends PiranhaMessage {
  constructor(c, d) {
    super(d);
    this.session = d;
    this.id = 0x37de;
    this.version = 0x0;
    this.stream = new ByteStream(c);
  }
  async ["decode"]() {
    this.stream.readInt();
    this.LowID = this.stream.readInt();
  }
  async ["process"]() {
    const c = await database.getClub(this.LowID);
    const d = c.members.map(f => database.getUserClub(f));
    const e = await Promise.all(d);
    new AllianceDataMessage(this.session, c, e).send();
  }
}
module.exports = AskForAllianceDataMessage;