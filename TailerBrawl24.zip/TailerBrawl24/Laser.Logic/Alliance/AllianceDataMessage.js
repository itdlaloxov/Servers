const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")
const Alliance = require("../../Utils/Entry/Alliance");

class AllianceDataMessage extends PiranhaMessage {
  constructor(c, d, e) {
    super(c);
    this.id = 0x5eed;
    this.session = c;
    this.version = 0x1;
    this.club = d;
    this.members = e;
    this.stream = new ByteStream();
  }
  async ["encode"]() {
    this.stream.writeBoolean(this.session.ClubID === this.club.clubID);
    new Alliance().encode(this.stream, this.club, this.members);
  }
}
module.exports = AllianceDataMessage;