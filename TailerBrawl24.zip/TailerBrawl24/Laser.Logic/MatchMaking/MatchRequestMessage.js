
const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

const LoginFailedMessage = require('../Account/LoginFailedMessage');
const MatchMakingCancelledMessage = require('./MatchMakingCancelledMessage');


class MatchRequestMessage extends PiranhaMessage {
  constructor (bytes, session) {
    super(session)
    this.session = session
    this.id = 14103
    this.version = 0
    this.stream = new ByteStream(bytes)
  }

  async decode () {
    this.stream.readVInt()
    this.session.BrawlerID = this.stream.readVInt()
    this.stream.readVInt()
    this.EventSlot = this.stream.readVInt()
    // ***
    // EventSlot
    // 1 - GemGrab
    // 2 - Showndoun
    // 5 - DuoShowndoun
  }

  async process () {
	new MatchMakingCancelledMessage(this.session).send();
  }
}

module.exports = MatchRequestMessage
