
const PiranhaMessage = require('../../Utils/PiranhaMessage')
const ByteStream = require("../../Utils/ByteStream")

class MatchMakingCancelledMessage extends PiranhaMessage {
  constructor (session, Players) {
    super(session)
    this.id = 20406
    this.session = session
    this.Players = Players
    this.version = 0
    this.stream = new ByteStream()
  }

  async encode () {
    this.stream.writeInt(1);
  }
}

module.exports = MatchMakingCancelledMessage
