class LogicGameObjectManager {
    constructor() {
        this.InputCounter = 0;

        this.PlayerX = 2550;
        this.PlayerY = 2550;
    }
}
module.exports = LogicGameObjectManager;